function CreateJob() {}
$.extend(CreateJob.prototype, {
	data: null,
	currentOrgId: 'province',
	currentBranch: '',
	currentKeyword: '',
	currentPage: 1,
	pageSize: 10,
	init: function () {
		if (!window.JOBS_DATA) {
			$('.noData').css('display', 'flex');
			$('.job_list').empty();
			$('#jobPager').attr('hidden', true).empty();
			return;
		}
		this.data = window.JOBS_DATA;
		this.renderOrgs();
		var firstOrg = (this.visibleOrgs() || [])[0];
		this.selectOrg(firstOrg ? firstOrg.id : 'province');
	},
	hasZhaopin: function (job) {
		if (!job) return false;
		if (String(job.zhaopinNumber || '').trim()) return true;
		return String(job.zhaopinUrl || '').indexOf('/job/') > -1;
	},
	hasGuopin: function (job) {
		if (!job) return false;
		return String(job.iguopinUrl || '').indexOf('job/detail') > -1;
	},
	visibleJobs: function (list) {
		var self = this;
		return (list || []).filter(function (m) {
			return self.hasZhaopin(m);
		});
	},
	visibleOrgs: function () {
		var self = this;
		return (this.data.orgs || []).filter(function (org) {
			return self.getJobs(org.id, '').length > 0;
		});
	},
	renderOrgs: function () {
		var html = '';
		$.each(this.visibleOrgs(), function (i, org) {
			html +=
				'<li class="' +
				(i === 0 ? 'active' : '') +
				'">' +
				'<a href="javascript:void(0);"><p data-id="' +
				org.id +
				'">' +
				org.name +
				'</p></a>' +
				'</li>';
		});
		$('.ltab').html(html);
	},
	getOrg: function (orgId) {
		return (this.data.orgs || []).find(function (o) {
			return o.id === orgId;
		});
	},
	displayBranchName: function (name) {
		return String(name || '').replace(/分公司/g, '');
	},
	renderBranches: function (orgId) {
		var org = this.getOrg(orgId);
		var branches = ((org && org.branches) || []).slice();
		branches = branches
			.filter(function (b) {
				return b !== '其他';
			})
			.concat(
				branches.filter(function (b) {
					return b === '其他';
				})
			);
		var self = this;
		branches = branches.filter(function (b) {
			return self.getJobs(orgId, b).length > 0;
		});
		if (!branches.length) {
			$('.snav').hide();
			$('#chorgList').empty();
			this.currentBranch = '';
			return;
		}
		var html = '<li class="active"><a href="javascript:void(0);" data-branch="">全部</a></li>';
		$.each(branches, function (_, b) {
			html +=
				'<li><a href="javascript:void(0);" data-branch="' +
				b +
				'">' +
				self.displayBranchName(b) +
				'</a></li>';
		});
		$('#chorgList').html(html);
		$('.snav').show();
		this.currentBranch = '';
	},
	getJobs: function (orgId, branch) {
		var pack = (this.data.jobsByOrg && this.data.jobsByOrg[orgId]) || { all: [], byBranch: {} };
		var list = !branch ? pack.all || [] : (pack.byBranch && pack.byBranch[branch]) || [];
		return this.visibleJobs(list);
	},
	filterJobs: function (list, keyword) {
		var kw = (keyword || '').replace(/\s+/g, '').toLowerCase();
		if (!kw) return list || [];
		return (list || []).filter(function (m) {
			var text = [m.title, m.full]
				.join('')
				.replace(/\s+/g, '')
				.toLowerCase();
			return text.indexOf(kw) > -1;
		});
	},
	selectOrg: function (orgId) {
		this.currentOrgId = orgId;
		this.renderBranches(orgId);
		this.renderJobs(orgId, '', this.currentKeyword);
	},
	renderJobs: function (orgId, branch, keyword, page) {
		this.currentOrgId = orgId;
		this.currentBranch = branch || '';
		if (typeof keyword === 'string') {
			this.currentKeyword = keyword;
		}
		this.currentPage = page > 0 ? page : 1;
		var list = this.filterJobs(this.getJobs(orgId, this.currentBranch), this.currentKeyword);
		var pageSize = this.pageSize;
		var pageCount = Math.max(1, Math.ceil(list.length / pageSize));
		if (this.currentPage > pageCount) this.currentPage = pageCount;
		var start = (this.currentPage - 1) * pageSize;
		var pageList = list.slice(start, start + pageSize);
		var html = '';
		var self = this;
		if (list.length) {
			$('.noData').hide();
			$.each(pageList, function (_, m) {
				var branchName = self.displayBranchName(m.branch || '');
				if (branchName === '省本部') branchName = '';
				var jobTitle = m.title || m.full || '';
				var displayName = m.full || jobTitle;
				var shineTag =
					m.category === 'shine'
						? '<img class="job-tag-shine" src="images/syxm.png" alt="闪耀新苗">'
						: '';
				var descriptionText = String(m.description || '').trim();
				var descriptionHtml = descriptionText
					? '<div class="job-description-text">' + $('<div>').text(descriptionText).html().replace(/\r?\n/g, '<br>') + '</div>'
					: '<div class="job-description-empty">暂无岗位描述</div>';
				html +=
					'<li>' +
					'<a class="list_btn" href="javascript:void(0);" title="立即投递" data-title="' +
					$('<div>').text(displayName).html() +
					'" data-gp="' +
					$('<div>').text(m.iguopinUrl || '').html() +
					'" data-zp-number="' +
					$('<div>').text(m.zhaopinNumber || '').html() +
					'" data-zp="' +
					$('<div>').text(m.zhaopinUrl || '').html() +
					'"><img src="images/icon_toudi.png"><span>立即投递</span></a>' +
					'<a href="javascript:void(0);" class="list_top" aria-expanded="false" onclick="var i=this.parentNode,e=!i.classList.contains(\'active\');i.classList.toggle(\'active\',e);this.setAttribute(\'aria-expanded\',e);">' +
					'<em></em>' +
					'<strong>' +
					jobTitle +
					'</strong>' +
					shineTag +
					(branchName ? '<span class="job-branch">' + branchName + '</span>' : '') +
					'</a>' +
					'<div class="list_con">' + descriptionHtml + '</div>' +
					'</li>';
			});
		} else {
			html = '';
			$('.noData').css('display', 'flex');
			$('.noData p').text(this.currentKeyword ? '未找到相关岗位' : '暂无职位，敬请期待！');
		}
		$('.job_list').html(html);
		this.renderPager(list.length, this.currentPage, pageCount);
		if (page > 1) {
			var listEl = document.querySelector('.job_list');
			if (listEl && listEl.scrollIntoView) {
				listEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}
		}
	},
	renderPager: function (total, page, pageCount) {
		var $pager = $('#jobPager');
		if (!total || pageCount <= 1) {
			$pager.attr('hidden', true).empty();
			return;
		}
		var html = '';
		if (page > 1) {
			html += '<a href="javascript:void(0);" data-page="' + (page - 1) + '">上一页</a>';
		}
		var start = Math.max(1, page - 2);
		var end = Math.min(pageCount, page + 2);
		if (start > 1) {
			html += '<a href="javascript:void(0);" data-page="1">1</a>';
			if (start > 2) html += '<span class="job-pager-ellipsis">...</span>';
		}
		for (var i = start; i <= end; i++) {
			if (i === page) {
				html += '<span class="active">' + i + '</span>';
			} else {
				html += '<a href="javascript:void(0);" data-page="' + i + '">' + i + '</a>';
			}
		}
		if (end < pageCount) {
			if (end < pageCount - 1) html += '<span class="job-pager-ellipsis">...</span>';
			html += '<a href="javascript:void(0);" data-page="' + pageCount + '">' + pageCount + '</a>';
		}
		if (page < pageCount) {
			html += '<a href="javascript:void(0);" data-page="' + (page + 1) + '">下一页</a>';
		}
		$pager.html(html).removeAttr('hidden');
	}
});

$(function () {
	var createJob = new CreateJob();
	createJob.init();

	function applySearch() {
		var kw = ($('#jobSearchInput').val() || '').trim();
		createJob.renderJobs(createJob.currentOrgId, createJob.currentBranch, kw);
	}

	$('.ltab').on('click', 'li', function () {
		$('.ltab li').removeClass('active');
		$(this).addClass('active');
		var id = $(this).children('a').children('p').attr('data-id');
		createJob.selectOrg(id);
	});

	$('.snav').on('click', 'a', function () {
		$(this).parent('li').addClass('active').siblings('li').removeClass('active');
		var branch = $(this).attr('data-branch') || '';
		createJob.renderJobs(createJob.currentOrgId, branch, createJob.currentKeyword);
	});

	$('#jobPager').on('click', 'a', function (e) {
		e.preventDefault();
		var page = parseInt($(this).attr('data-page'), 10);
		if (!page || page === createJob.currentPage) return;
		createJob.renderJobs(createJob.currentOrgId, createJob.currentBranch, createJob.currentKeyword, page);
	});

	$('#jobSearchBtn').on('click', applySearch);
	$('#jobSearchInput').on('keydown', function (e) {
		if (e.key === 'Enter') {
			e.preventDefault();
			applySearch();
		}
	});
	$('#jobSearchInput').on('input', function () {
		applySearch();
	});

	var $modal = $('#applyModal');
	var $jobName = $modal.find('.apply-job-name');
	var $btnGp = $modal.find('.apply-btn-gp');
	var $btnZp = $modal.find('.apply-btn-zp');
	var GP_DETAIL = /job\/detail/;

	function buildZhaopinUrl(number, fallbackUrl) {
		var num = (number || '').trim();
		if (num) {
			return 'https://xiaoyuan.zhaopin.com/job/' + encodeURIComponent(num) + '?srccode=448002';
		}
		var fb = (fallbackUrl || '').trim();
		if (fb && fb.indexOf('/job/') > -1) return fb;
		return '';
	}

	function setApplyBtn($btn, url, enabledTitle, disabledTitle) {
		if (url) {
			$btn
				.attr('href', url)
				.removeClass('is-disabled')
				.removeAttr('aria-disabled')
				.attr('title', enabledTitle);
		} else {
			$btn
				.attr('href', 'javascript:void(0);')
				.addClass('is-disabled')
				.attr('aria-disabled', 'true')
				.attr('title', disabledTitle);
		}
	}

	function openApplyModal(title, gpUrl, zpNumber, zpUrl) {
		$jobName.text(title || '');
		var gp = (gpUrl || '').trim();
		if (!GP_DETAIL.test(gp)) gp = '';
		var zp = buildZhaopinUrl(zpNumber, zpUrl);
		setApplyBtn($btnGp, gp, '国聘招聘投递', '该岗位暂未在国聘发布详情');
		setApplyBtn($btnZp, zp, '智联招聘投递', '该岗位暂未在智联发布详情');
		$modal.find('.apply-modal-zp-tip').toggle((!gp && !!zp) || (!!gp && !zp));
		$modal.find('.apply-modal-zp-tip span').text(
			!gp ? '该岗位暂未在国聘发布详情，请使用智联投递' : '该岗位暂未在智联发布详情，请改用国聘投递'
		);
		$modal.prop('hidden', false);
		$('body').addClass('apply-modal-open');
	}

	function closeApplyModal() {
		$modal.prop('hidden', true);
		$('body').removeClass('apply-modal-open');
	}

	$('.job_list').on('click', '.list_btn', function (e) {
		e.preventDefault();
		e.stopPropagation();
		var $btn = $(this);
		openApplyModal(
			$btn.attr('data-title') || '',
			$btn.attr('data-gp') || '',
			$btn.attr('data-zp-number') || '',
			$btn.attr('data-zp') || ''
		);
	});

	$btnGp.add($btnZp).on('click', function (e) {
		if ($(this).hasClass('is-disabled')) {
			e.preventDefault();
		}
	});

	$modal.on('click', '[data-close]', function () {
		closeApplyModal();
	});

	$(document).on('keydown.applyModal', function (e) {
		if (e.key === 'Escape' && !$modal.prop('hidden')) {
			closeApplyModal();
		}
	});
});
