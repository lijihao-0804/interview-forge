(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.JobDescription = factory();
  }
})(typeof window !== 'undefined' ? window : globalThis, function () {
  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function (character) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[character];
    });
  }

  function formatDescriptionHtml(value) {
    var description = String(value || '').trim();
    if (!description) {
      return '<div class="job-description-empty">暂无岗位描述</div>';
    }
    return '<div class="job-description-text">' +
      escapeHtml(description).replace(/\r?\n/g, '<br>') +
      '</div>';
  }

  return { escapeHtml: escapeHtml, formatDescriptionHtml: formatDescriptionHtml };
});
